# MindBridge — AI-Powered Psychological Intervention System

A full-stack digital mental-health intervention platform for colleges: student self-help tools, AI first-aid chat, validated PHQ-9/GAD-7 screening, confidential counsellor booking, a moderated peer community, and anonymized admin analytics.

This repo contains two apps:

```
backend/    FastAPI + SQLAlchemy + SQLite + JWT + Gemini AI
frontend/   React (Vite) + Tailwind + Recharts + Axios
```

The UI is unchanged from the original design prototype — every page, color, layout, and animation is preserved. What changed is that every screen now reads and writes real data through the FastAPI backend instead of hardcoded arrays.

---

## 1. Backend setup

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # edit values as needed
uvicorn app.main:app --reload
```

The API runs at `http://localhost:8000`. Interactive docs: `http://localhost:8000/docs`.

On first run, the database (`mindbridge.db`, SQLite) is created automatically and seeded with:

| Role | Email | Password |
|---|---|---|
| Admin | admin@mindbridge.edu | Admin@123 |
| Counsellor | ananya.rao@mindbridge.edu | Counsellor@123 |
| Counsellor | kabir.mehta@mindbridge.edu | Counsellor@123 |
| Counsellor | sana.ilyas@mindbridge.edu | Counsellor@123 |

Students register themselves from the app's "Create a student account" flow.

### Gemini AI (optional)

The AI chat works out of the box without any key, using a built-in rule-based first-aid responder. To use real Gemini responses:

1. Get a key at https://aistudio.google.com/apikey
2. Set `GEMINI_API_KEY` in `backend/.env`
3. Restart the server

Crisis-language detection runs locally on every message regardless of whether Gemini is configured, since that safety check must never depend on an external API being up.

---

## 2. Frontend setup

```bash
cd frontend
npm install
cp .env.example .env    # VITE_API_URL=http://localhost:8000
npm run dev
```

Visit `http://localhost:5173`.

`npm run build` produces a production bundle in `frontend/dist/`.

---

## 3. Architecture

### Data model (SQLAlchemy, `backend/app/models.py`)

- **User** — auth, role (student/counsellor/volunteer/admin), department, hostel flag, anonymous_id, counsellor specialization/rating
- **MoodLog** — daily mood/sleep/stress/journal check-ins
- **Assessment** — PHQ-9 / GAD-7 submissions, score, risk level, high-risk flag
- **ChatMessage** — AI chat history, keyed by session, with a crisis flag
- **Resource** — resource hub content (category, type, language, duration)
- **Appointment** — counsellor bookings (mode, anonymity, QR code, status)
- **ForumPost** — peer support posts, reply/report counters
- **Notification** — in-app alerts (e.g. counsellors notified on high-risk screenings or crisis chats)

### API surface (`backend/app/routers/`)

| Router | Prefix | Purpose |
|---|---|---|
| auth | `/api/auth` | register, login (JWT), current user |
| dashboard | `/api/dashboard` | role-specific dashboard aggregates |
| mood | `/api/mood` | check-in + history |
| assessments | `/api/assessments` | PHQ-9 / GAD-7 questions, scoring, history |
| chat | `/api/chat` | AI first-aid chat, crisis detection, history |
| resources | `/api/resources` | resource hub CRUD + filters |
| appointments | `/api/appointments` | counsellor listing, booking, status |
| peer | `/api/peer` | forum posts, replies, reports |
| notifications | `/api/notifications` | in-app alerts |
| admin | `/api/admin` | live analytics computed from the database |

Full interactive reference: `http://localhost:8000/docs`.

### Security

- Passwords hashed with bcrypt (passlib)
- JWT bearer tokens (python-jose), role embedded in the token and re-verified against the DB on every request
- Role-based route guards (`require_roles(...)`) on every sensitive endpoint
- Pydantic request validation on every input (score ranges, enum values, string lengths)
- Centralized exception handlers so unexpected errors never leak stack traces to the client
- CORS restricted to the configured frontend origin(s)

### Crisis handling

Every message sent to `/api/chat/message` and every peer-support post is scanned locally for crisis language before anything else happens. If detected:

1. The AI stops normal conversation and returns a supportive message plus a list of real crisis helplines (KIRAN, Vandrevala Foundation, iCall, campus counsellor).
2. All counsellor accounts (for chat) or volunteer accounts (for forum posts) receive an in-app notification.
3. PHQ-9 item 9 ("thoughts you'd be better off dead...") being answered above 0 always sets `high_risk_flag`, regardless of total score, and notifies counsellors the same way.

---

## 4. Known limitations (by design, for a reference build)

- SQLite is used for simplicity; swap `DATABASE_URL` for Postgres in production.
- Appointment "next available" times in the booking UI are illustrative; a production system would need real counsellor calendars.
- The Gemini fallback responder is rule-based and intentionally simple — it exists so the app is fully functional without an API key, not as a clinical tool.
- This is a hackathon/demo-grade reference implementation, not a certified medical device. It is not a substitute for professional mental health care.

import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  Heart, MessageCircle, Calendar, BookOpen, Users, ClipboardList,
  AlertTriangle, Sun, Moon, Smile, Meh, Frown, Send, ChevronRight,
  Shield, TrendingUp, Bell, LogOut, Home, PhoneCall, X, Check,
  Sparkles, BarChart3, GraduationCap, UserCog, HeartHandshake,
  Lock, ArrowRight, Clock, MapPin, Video, Star, Search, Bookmark,
  Activity, Droplet, Moon as MoonIcon, Award, Loader2, RefreshCw
} from "lucide-react";
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell
} from "recharts";

import {
  registerUnauthorizedHandler, registerUser, loginUser, fetchMe,
  fetchStudentDashboard, fetchCounsellorDashboard, fetchVolunteerDashboard,
  submitMoodCheckin, fetchMoodHistory,
  fetchAssessmentQuestions, submitAssessment,
  sendChatMessage, fetchChatHistory,
  fetchResources, fetchResourceCategories, fetchResourceLanguages,
  fetchCounsellors, bookAppointment,
  fetchPeerPosts, createPeerPost, reportPost,
  fetchNotifications, markNotificationRead,
  fetchAdminAnalytics,
} from "./api/client";

/* ------------------------------------------------------------------ */
/* MindBridge — Digital Psychological Intervention System              */
/* Full-stack build: React + FastAPI + SQLAlchemy + JWT + Gemini AI    */
/* ------------------------------------------------------------------ */

const COLORS = { primary: "#4F8EF7", secondary: "#6FCF97", accent: "#9B8AFB" };

const CRISIS_LINES = [
  { name: "KIRAN Mental Health Helpline (Govt. of India)", number: "1800-599-0019", availability: "24/7, toll-free" },
  { name: "Vandrevala Foundation Helpline", number: "1860-2662-345", availability: "24/7" },
  { name: "iCall (TISS)", number: "9152987821", availability: "Mon–Sat, 10am–8pm" },
  { name: "Campus Counsellor (on-call)", number: "Ext. 4477", availability: "24/7 for enrolled students" },
];

/* ---------------------------- Shared UI ---------------------------- */

function Logo({ dark }) {
  return (
    <div className="flex items-center gap-2">
      <div className="relative w-8 h-8 flex items-center justify-center rounded-xl" style={{ background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})` }}>
        <Heart size={16} className="text-white" fill="white" />
      </div>
      <span className={`font-bold text-lg tracking-tight ${dark ? "text-white" : "text-slate-800"}`}>MindBridge</span>
    </div>
  );
}

function Card({ children, className = "", dark }) {
  return (
    <div className={`rounded-3xl border transition-shadow ${dark ? "bg-slate-800/60 border-slate-700" : "bg-white border-slate-100"} shadow-sm hover:shadow-md ${className}`}>
      {children}
    </div>
  );
}

function Pill({ children, tone = "primary" }) {
  const map = {
    primary: "bg-[#4F8EF7]/10 text-[#4F8EF7]",
    secondary: "bg-[#6FCF97]/15 text-[#3fa76b]",
    accent: "bg-[#9B8AFB]/15 text-[#7a67e8]",
    warn: "bg-amber-100 text-amber-700",
    danger: "bg-rose-100 text-rose-600",
  };
  return <span className={`px-3 py-1 rounded-full text-xs font-medium ${map[tone]}`}>{children}</span>;
}

function PrimaryButton({ children, onClick, className = "", icon: Icon, disabled, loading }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled || loading}
      className={`inline-flex items-center justify-center gap-2 px-5 py-3 rounded-2xl font-medium text-white shadow-sm hover:shadow-md active:scale-[0.98] transition-all disabled:opacity-60 disabled:cursor-not-allowed ${className}`}
      style={{ background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})` }}
    >
      {loading ? <Loader2 size={16} className="animate-spin" /> : <>{children} {Icon && <Icon size={16} />}</>}
    </button>
  );
}

function GhostButton({ children, onClick, className = "", dark, disabled }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`inline-flex items-center justify-center gap-2 px-5 py-3 rounded-2xl font-medium border transition-all active:scale-[0.98] disabled:opacity-60 ${
        dark ? "border-slate-600 text-slate-200 hover:bg-slate-800" : "border-slate-200 text-slate-700 hover:bg-slate-50"
      } ${className}`}
    >
      {children}
    </button>
  );
}

function Spinner({ label = "Loading..." }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 gap-3 text-slate-400">
      <Loader2 size={26} className="animate-spin" style={{ color: COLORS.primary }} />
      <span className="text-sm">{label}</span>
    </div>
  );
}

function ErrorState({ message, onRetry }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 gap-3 text-center px-6">
      <div className="w-12 h-12 rounded-2xl bg-rose-50 flex items-center justify-center">
        <AlertTriangle size={22} className="text-rose-500" />
      </div>
      <p className="text-sm text-slate-500 max-w-sm">{message || "Something went wrong while loading this."}</p>
      {onRetry && (
        <button onClick={onRetry} className="flex items-center gap-1.5 text-sm font-medium" style={{ color: COLORS.primary }}>
          <RefreshCw size={14} /> Try again
        </button>
      )}
    </div>
  );
}

/** Generic async data hook: handles loading / error / retry for any fetcher. */
function useApi(fetcher, deps = []) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    setError(null);
    fetcher()
      .then((res) => { if (alive) setData(res); })
      .catch((err) => { if (alive) setError(err.message); })
      .finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick]);

  return { data, loading, error, refetch: () => setTick((t) => t + 1), setData };
}

/* ---------------------------- Emergency Modal ---------------------------- */

function EmergencyModal({ onClose, onBook }) {
  return (
    <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4" onClick={onClose}>
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl p-6 animate-[fadeIn_0.2s_ease]" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-[#6FCF97]/20 flex items-center justify-center">
              <Shield size={20} className="text-[#3fa76b]" />
            </div>
            <h3 className="font-bold text-lg text-slate-800">You're not alone</h3>
          </div>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-slate-100"><X size={18} /></button>
        </div>
        <p className="text-sm text-slate-500 mb-5 leading-relaxed">
          If you're in crisis or feel unsafe right now, please reach out immediately. Someone is available to talk, right now.
        </p>
        <div className="space-y-3 mb-5">
          {CRISIS_LINES.map((c, i) => (
            <div key={i} className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-100">
              <div>
                <div className="text-sm font-medium text-slate-700">{c.name}</div>
                <div className="text-xs text-slate-400">{c.availability}</div>
              </div>
              <a href={`tel:${c.number.replace(/[^0-9+]/g, "")}`} className="flex items-center gap-1.5 text-sm font-semibold text-[#4F8EF7]">
                <PhoneCall size={14} /> {c.number}
              </a>
            </div>
          ))}
        </div>
        <PrimaryButton className="w-full" icon={Calendar} onClick={onBook}>Book an urgent counsellor slot</PrimaryButton>
        <p className="text-[11px] text-slate-400 text-center mt-3">
          These are real national and campus helplines. In a live deployment, campus numbers would be verified by your institution.
        </p>
      </div>
    </div>
  );
}

function EmergencyFAB({ onOpen }) {
  return (
    <button
      onClick={onOpen}
      className="fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-3.5 rounded-full text-white font-semibold shadow-lg shadow-rose-200/60 hover:scale-105 active:scale-95 transition-transform"
      style={{ background: "linear-gradient(135deg,#f76b6b,#f79b6b)" }}
    >
      <Shield size={18} /> <span className="hidden sm:inline">Emergency Help</span>
    </button>
  );
}

/* ---------------------------- Landing Page ---------------------------- */

function Landing({ goAuth, dark, setDark }) {
  const stats = [
    { n: "1 in 3", l: "college students report high stress during exams" },
    { n: "60%", l: "hesitate to seek help due to stigma" },
    { n: "24/7", l: "AI first-aid support availability" },
    { n: "100%", l: "anonymous, encrypted conversations" },
  ];
  const features = [
    { icon: MessageCircle, title: "AI First-Aid Chat", desc: "A calm, always-available first conversation — grounding techniques, CBT-inspired reframing, and clear escalation when it matters." },
    { icon: ClipboardList, title: "Validated Screening", desc: "PHQ-9 and GAD-7 assessments with plain-language reports and trend tracking." },
    { icon: Calendar, title: "Confidential Booking", desc: "Book a counsellor anonymously, online or in person, with QR check-in." },
    { icon: BookOpen, title: "Resource Hub", desc: "Bite-sized guides, audio, and video in multiple regional languages." },
    { icon: Users, title: "Peer Community", desc: "Moderated, anonymous peer support run by trained student volunteers." },
    { icon: Activity, title: "Mood Tracking", desc: "A 20-second daily check-in that reveals patterns over weeks and months." },
  ];
  return (
    <div className={dark ? "bg-slate-950 text-slate-100" : "bg-[#F8FAFC] text-slate-800"}>
      <nav className="sticky top-0 z-40 backdrop-blur-md border-b" style={{ borderColor: dark ? "#1e293b" : "#eef2f7", background: dark ? "rgba(2,6,23,0.7)" : "rgba(248,250,252,0.7)" }}>
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <Logo dark={dark} />
          <div className="flex items-center gap-3">
            <button onClick={() => setDark(!dark)} className={`p-2 rounded-full ${dark ? "hover:bg-slate-800" : "hover:bg-slate-100"}`}>
              {dark ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            <GhostButton dark={dark} onClick={() => goAuth("login")}>Log in</GhostButton>
          </div>
        </div>
      </nav>

      <header className="max-w-6xl mx-auto px-6 pt-16 pb-20 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <Pill tone="secondary">Built for campus mental health teams</Pill>
          <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mt-5 leading-[1.1]">
            Supporting students <span style={{ color: COLORS.primary }}>before</span> they reach a crisis.
          </h1>
          <p className={`mt-5 text-lg leading-relaxed ${dark ? "text-slate-400" : "text-slate-500"}`}>
            MindBridge connects students, counsellors, peer volunteers and administrators on one calm, private platform —
            built for early intervention, not just crisis response.
          </p>
          <div className="flex flex-wrap gap-3 mt-8">
            <PrimaryButton onClick={() => goAuth("register")} icon={ArrowRight}>Create a student account</PrimaryButton>
            <GhostButton dark={dark} onClick={() => goAuth("login")}>Staff &amp; counsellor login</GhostButton>
          </div>
          <div className="flex items-center gap-2 mt-6 text-sm text-slate-400">
            <Lock size={14} /> End-to-end JWT auth · Anonymous by default
          </div>
        </div>
        <div className="relative">
          <div className="absolute -inset-8 rounded-full blur-3xl opacity-30" style={{ background: `radial-gradient(circle, ${COLORS.accent}, transparent 70%)` }} />
          <Card dark={dark} className="relative p-6">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})` }}>
                <Sparkles size={16} className="text-white" />
              </div>
              <div>
                <div className="text-sm font-semibold">MindBridge AI</div>
                <div className="text-xs text-slate-400">First-aid support</div>
              </div>
            </div>
            <div className="space-y-3 text-sm">
              <div className={`ml-auto max-w-[80%] rounded-2xl rounded-tr-sm px-4 py-2.5 ${dark ? "bg-slate-700" : "bg-slate-100"}`}>
                My exams are stressing me out and I can't sleep.
              </div>
              <div className="max-w-[85%] rounded-2xl rounded-tl-sm px-4 py-2.5 text-white" style={{ background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})` }}>
                That sounds exhausting to carry. Let's try a 4-7-8 breathing exercise together, then look at one small thing for tomorrow — okay?
              </div>
            </div>
          </Card>
        </div>
      </header>

      <section className={`py-14 ${dark ? "bg-slate-900" : "bg-white"}`}>
        <div className="max-w-6xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((s, i) => (
            <div key={i} className="text-center">
              <div className="text-3xl font-bold" style={{ color: COLORS.primary }}>{s.n}</div>
              <div className="text-xs text-slate-400 mt-2 leading-snug">{s.l}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-6 py-20">
        <h2 className="text-3xl font-bold text-center">Everything a campus wellness team needs</h2>
        <p className="text-center text-slate-400 mt-2 max-w-xl mx-auto">One platform for students, counsellors, volunteers and administrators — private by design.</p>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-5 mt-12">
          {features.map((f, i) => (
            <Card key={i} dark={dark} className="p-6">
              <div className="w-11 h-11 rounded-2xl flex items-center justify-center mb-4" style={{ background: `${COLORS.primary}15` }}>
                <f.icon size={20} style={{ color: COLORS.primary }} />
              </div>
              <h3 className="font-semibold mb-1.5">{f.title}</h3>
              <p className="text-sm text-slate-400 leading-relaxed">{f.desc}</p>
            </Card>
          ))}
        </div>
      </section>

      <section className={`py-20 ${dark ? "bg-slate-900" : "bg-white"}`}>
        <div className="max-w-5xl mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12">How it works</h2>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { t: "Check in", d: "A 20-second daily mood log or a chat with the AI first-aid assistant." },
              { t: "Understand", d: "Validated screening gives a clear, private picture of how you're doing." },
              { t: "Connect", d: "Book a counsellor, join peer support, or explore self-help resources." },
              { t: "Grow", d: "Track progress over time with gentle, encouraging insights." },
            ].map((s, i) => (
              <div key={i} className="relative">
                <div className="text-xs font-mono text-slate-400 mb-2">Step {i + 1}</div>
                <h4 className="font-semibold mb-1">{s.t}</h4>
                <p className="text-sm text-slate-400">{s.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className={`py-20 ${dark ? "bg-slate-900" : "bg-white"} border-t`} style={{ borderColor: dark ? "#1e293b" : "#eef2f7" }}>
        <div className="max-w-3xl mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-10">Frequently asked questions</h2>
          <div className="space-y-3">
            {[
              { q: "Is my data really anonymous?", a: "Your identity is decoupled from your wellness data using anonymous IDs. Admins only ever see aggregated, de-identified trends." },
              { q: "Does the AI chatbot diagnose me?", a: "No. It offers first-aid style support and always points you toward a licensed counsellor for anything clinical." },
              { q: "What happens if I'm in crisis?", a: "The Emergency Help button is visible on every page and connects you to campus and national crisis lines immediately." },
            ].map((f, i) => (
              <details key={i} className={`group rounded-2xl border p-4 ${dark ? "border-slate-700" : "border-slate-100"}`}>
                <summary className="flex items-center justify-between cursor-pointer font-medium text-sm">
                  {f.q} <ChevronRight size={16} className="group-open:rotate-90 transition-transform" />
                </summary>
                <p className="text-sm text-slate-400 mt-2 leading-relaxed">{f.a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <footer className="py-10 text-center text-xs text-slate-400 border-t" style={{ borderColor: dark ? "#1e293b" : "#eef2f7" }}>
        MindBridge — a full-stack reference build. Not a substitute for professional mental health care.
      </footer>
    </div>
  );
}

/* ---------------------------- Auth (Login / Register) ---------------------------- */

function AuthScreen({ mode, setMode, onAuthed, dark }) {
  const roles = [
    { id: "student", label: "Student", icon: GraduationCap },
    { id: "counsellor", label: "Counsellor", icon: HeartHandshake },
    { id: "volunteer", label: "Peer Volunteer", icon: Users },
    { id: "admin", label: "Administrator", icon: UserCog },
  ];
  const [role, setRole] = useState("student");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [department, setDepartment] = useState("");
  const [year, setYear] = useState("");
  const [isHostel, setIsHostel] = useState(false);
  const [specialization, setSpecialization] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function submit() {
    setError("");
    if (!email || !password || (mode === "register" && !fullName)) {
      setError("Please fill in all required fields.");
      return;
    }
    setLoading(true);
    try {
      const data =
        mode === "register"
          ? await registerUser({
              full_name: fullName, email, password, role,
              department: department || null, year: year || null,
              is_hostel: isHostel, specialization: specialization || null,
            })
          : await loginUser(email, password);
      onAuthed(data.access_token, data.user);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className={`min-h-screen flex items-center justify-center px-6 py-10 ${dark ? "bg-slate-950" : "bg-[#F8FAFC]"}`}>
      <Card dark={dark} className="w-full max-w-md p-8">
        <div className="flex justify-center mb-6"><Logo dark={dark} /></div>
        <h2 className={`text-xl font-bold text-center ${dark ? "text-white" : "text-slate-800"}`}>
          {mode === "register" ? "Create your account" : "Welcome back"}
        </h2>
        <p className="text-sm text-slate-400 text-center mt-1 mb-6">
          {mode === "register" ? "Choose your role to get started" : "Choose how you'd like to sign in"}
        </p>

        <div className="grid grid-cols-2 gap-3 mb-5">
          {roles.map((r) => (
            <button
              key={r.id}
              onClick={() => setRole(r.id)}
              className={`flex flex-col items-center gap-2 p-4 rounded-2xl border text-sm font-medium transition-all ${
                role === r.id ? "border-transparent text-white shadow-md" : dark ? "border-slate-700 text-slate-300 hover:bg-slate-800" : "border-slate-200 text-slate-600 hover:bg-slate-50"
              }`}
              style={role === r.id ? { background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})` } : {}}
            >
              <r.icon size={20} /> {r.label}
            </button>
          ))}
        </div>

        <div className="space-y-3">
          {mode === "register" && (
            <input value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Full name" className={`w-full px-4 py-3 rounded-xl border text-sm outline-none focus:ring-2 focus:ring-[#4F8EF7]/40 ${dark ? "bg-slate-900 border-slate-700 text-white" : "bg-slate-50 border-slate-200"}`} />
          )}
          <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Institution email" type="email" className={`w-full px-4 py-3 rounded-xl border text-sm outline-none focus:ring-2 focus:ring-[#4F8EF7]/40 ${dark ? "bg-slate-900 border-slate-700 text-white" : "bg-slate-50 border-slate-200"}`} />
          <input value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" type="password" className={`w-full px-4 py-3 rounded-xl border text-sm outline-none focus:ring-2 focus:ring-[#4F8EF7]/40 ${dark ? "bg-slate-900 border-slate-700 text-white" : "bg-slate-50 border-slate-200"}`} />

          {mode === "register" && role === "student" && (
            <div className="grid grid-cols-2 gap-3">
              <input value={department} onChange={(e) => setDepartment(e.target.value)} placeholder="Department" className={`px-4 py-3 rounded-xl border text-sm outline-none ${dark ? "bg-slate-900 border-slate-700 text-white" : "bg-slate-50 border-slate-200"}`} />
              <input value={year} onChange={(e) => setYear(e.target.value)} placeholder="Year" className={`px-4 py-3 rounded-xl border text-sm outline-none ${dark ? "bg-slate-900 border-slate-700 text-white" : "bg-slate-50 border-slate-200"}`} />
            </div>
          )}
          {mode === "register" && role === "student" && (
            <label className="flex items-center gap-2 text-sm text-slate-500">
              <input type="checkbox" checked={isHostel} onChange={(e) => setIsHostel(e.target.checked)} className="accent-[#4F8EF7]" /> I live in a hostel
            </label>
          )}
          {mode === "register" && role === "counsellor" && (
            <input value={specialization} onChange={(e) => setSpecialization(e.target.value)} placeholder="Specialization (e.g. Anxiety & academic stress)" className={`w-full px-4 py-3 rounded-xl border text-sm outline-none ${dark ? "bg-slate-900 border-slate-700 text-white" : "bg-slate-50 border-slate-200"}`} />
          )}
        </div>

        {error && <p className="text-xs text-rose-500 mt-3">{error}</p>}

        <PrimaryButton className="w-full mt-5" onClick={submit} loading={loading}>
          {mode === "register" ? "Create account" : `Continue as ${roles.find((r) => r.id === role).label}`}
        </PrimaryButton>

        <button
          onClick={() => setMode(mode === "register" ? "login" : "register")}
          className="w-full text-center text-xs text-slate-400 mt-4"
        >
          {mode === "register" ? "Already have an account? Log in" : "New here? Create an account"}
        </button>
        <p className="text-center text-xs text-slate-400 mt-2 flex items-center justify-center gap-1"><Lock size={12} /> Role-based access · JWT secured</p>
      </Card>
    </div>
  );
}

/* ---------------------------- Shell / Sidebar ---------------------------- */

function NotificationBell({ dark }) {
  const [open, setOpen] = useState(false);
  const { data, loading, refetch } = useApi(fetchNotifications, []);
  const unread = (data || []).filter((n) => !n.is_read).length;

  async function handleOpen() {
    setOpen((o) => !o);
    if (!open) refetch();
  }

  return (
    <div className="relative">
      <button onClick={handleOpen} className={`relative p-2 rounded-full ${dark ? "hover:bg-slate-800" : "hover:bg-slate-100"}`}>
        <Bell size={18} />
        {unread > 0 && <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-rose-500" />}
      </button>
      {open && (
        <div className={`absolute right-0 mt-2 w-80 rounded-2xl border shadow-lg z-30 max-h-96 overflow-y-auto ${dark ? "bg-slate-900 border-slate-700" : "bg-white border-slate-100"}`}>
          <div className="p-3 border-b border-slate-100 text-sm font-semibold">Notifications</div>
          {loading ? <Spinner label="Loading..." /> : (data || []).length === 0 ? (
            <p className="text-xs text-slate-400 p-4">You're all caught up.</p>
          ) : (
            (data || []).map((n) => (
              <button
                key={n.id}
                onClick={() => { markNotificationRead(n.id).then(refetch); }}
                className={`w-full text-left px-4 py-3 text-xs border-b last:border-0 border-slate-100 ${n.is_read ? "text-slate-400" : "text-slate-700 font-medium"}`}
              >
                {n.message}
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}

function Shell({ role, active, setActive, dark, setDark, onLogout, children }) {
  const menus = {
    student: [
      { id: "dashboard", label: "Dashboard", icon: Home },
      { id: "chat", label: "AI Support", icon: MessageCircle },
      { id: "assessment", label: "Assessments", icon: ClipboardList },
      { id: "booking", label: "Book Counsellor", icon: Calendar },
      { id: "resources", label: "Resource Hub", icon: BookOpen },
      { id: "mood", label: "Mood Tracker", icon: Activity },
      { id: "peer", label: "Peer Support", icon: Users },
    ],
    admin: [{ id: "admin", label: "Analytics", icon: BarChart3 }],
    counsellor: [{ id: "counsellor", label: "My Appointments", icon: Calendar }],
    volunteer: [{ id: "volunteer", label: "Volunteer Hub", icon: Users }],
  };
  const items = menus[role] || menus.student;
  return (
    <div className={`min-h-screen flex ${dark ? "bg-slate-950 text-slate-100" : "bg-[#F8FAFC] text-slate-800"}`}>
      <aside className={`w-64 shrink-0 hidden md:flex flex-col border-r p-5 ${dark ? "border-slate-800" : "border-slate-100"}`}>
        <Logo dark={dark} />
        <nav className="mt-8 flex-1 space-y-1">
          {items.map((m) => (
            <button
              key={m.id}
              onClick={() => setActive(m.id)}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                active === m.id ? "text-white" : dark ? "text-slate-400 hover:bg-slate-800" : "text-slate-500 hover:bg-slate-100"
              }`}
              style={active === m.id ? { background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})` } : {}}
            >
              <m.icon size={17} /> {m.label}
            </button>
          ))}
        </nav>
        <button onClick={() => setDark(!dark)} className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm ${dark ? "text-slate-400 hover:bg-slate-800" : "text-slate-500 hover:bg-slate-100"}`}>
          {dark ? <Sun size={17} /> : <Moon size={17} />} {dark ? "Light mode" : "Dark mode"}
        </button>
        <button onClick={onLogout} className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm ${dark ? "text-slate-400 hover:bg-slate-800" : "text-slate-500 hover:bg-slate-100"}`}>
          <LogOut size={17} /> Log out
        </button>
      </aside>

      <div className="flex-1 min-w-0">
        <div className={`flex items-center justify-between px-4 sm:px-8 py-3 border-b ${dark ? "border-slate-800" : "border-slate-100"}`}>
          <div className="md:hidden"><Logo dark={dark} /></div>
          <div className="hidden md:block" />
          <div className="flex items-center gap-2">
            <NotificationBell dark={dark} />
            <button onClick={onLogout} className="md:hidden p-2"><LogOut size={18} /></button>
          </div>
        </div>
        <div className="md:hidden flex gap-2 overflow-x-auto px-4 py-2 border-b border-slate-100">
          {items.map((m) => (
            <button key={m.id} onClick={() => setActive(m.id)} className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-medium ${active === m.id ? "text-white" : "bg-slate-100 text-slate-500"}`} style={active === m.id ? { background: COLORS.primary } : {}}>
              {m.label}
            </button>
          ))}
        </div>
        <main className="p-5 sm:p-8 max-w-6xl mx-auto">{children}</main>
      </div>
    </div>
  );
}

/* ---------------------------- Student Dashboard ---------------------------- */

function StudentDashboard({ dark, setActive }) {
  const { data, loading, error, refetch } = useApi(fetchStudentDashboard, []);

  if (loading) return <Spinner label="Loading your dashboard..." />;
  if (error) return <ErrorState message={error} onRetry={refetch} />;

  const quick = [
    { id: "chat", label: "AI Support", icon: MessageCircle },
    { id: "booking", label: "Book Counsellor", icon: Calendar },
    { id: "resources", label: "Resources", icon: BookOpen },
    { id: "peer", label: "Peer Support", icon: Users },
    { id: "assessment", label: "Assessments", icon: ClipboardList },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Hi {data.full_name.split(" ")[0]}, good to see you 👋</h1>
          <p className="text-sm text-slate-400 mt-1 italic">"{data.quote}"</p>
        </div>
        <Pill tone="secondary">Wellness score: {data.wellness_score}/100</Pill>
      </div>

      <div className="grid md:grid-cols-3 gap-5">
        <Card dark={dark} className="p-6 md:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-sm">Mood this week</h3>
            <button onClick={() => setActive("mood")} className="text-xs font-medium" style={{ color: COLORS.primary }}>Log today →</button>
          </div>
          {data.week_mood.length === 0 ? (
            <p className="text-sm text-slate-400 py-10 text-center">No check-ins yet this week — log your mood to see trends here.</p>
          ) : (
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={data.week_mood}>
                <defs>
                  <linearGradient id="moodGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={COLORS.primary} stopOpacity={0.35} />
                    <stop offset="100%" stopColor={COLORS.primary} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={dark ? "#1e293b" : "#eef2f7"} />
                <XAxis dataKey="day" tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                <YAxis hide domain={[0, 10]} />
                <Tooltip contentStyle={{ borderRadius: 12, border: "none", fontSize: 12 }} />
                <Area type="monotone" dataKey="score" stroke={COLORS.primary} strokeWidth={2.5} fill="url(#moodGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </Card>

        <Card dark={dark} className="p-6">
          <h3 className="font-semibold text-sm mb-4">Upcoming appointment</h3>
          {data.upcoming_appointment ? (
            <div className="flex items-start gap-3">
              <div className="w-11 h-11 rounded-2xl flex items-center justify-center shrink-0" style={{ background: `${COLORS.secondary}20` }}>
                <Video size={18} style={{ color: "#3fa76b" }} />
              </div>
              <div>
                <div className="text-sm font-medium">{data.upcoming_appointment.counsellor_name}</div>
                <div className="text-xs text-slate-400 mt-0.5">
                  {data.upcoming_appointment.mode === "online" ? "Online" : "In-person"} · {new Date(data.upcoming_appointment.scheduled_time).toLocaleString()}
                </div>
                <div className="text-xs text-slate-400">{data.upcoming_appointment.status}</div>
              </div>
            </div>
          ) : (
            <p className="text-sm text-slate-400">No upcoming sessions booked.</p>
          )}
          <GhostButton dark={dark} className="w-full mt-4 !py-2 text-xs" onClick={() => setActive("booking")}>Manage booking</GhostButton>
        </Card>
      </div>

      <div>
        <h3 className="font-semibold text-sm mb-3">Quick access</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {quick.map((q) => (
            <button key={q.id} onClick={() => setActive(q.id)} className="text-left">
              <Card dark={dark} className="p-4 h-full hover:-translate-y-0.5 transition-transform">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center mb-3" style={{ background: `${COLORS.primary}15` }}>
                  <q.icon size={17} style={{ color: COLORS.primary }} />
                </div>
                <div className="text-xs font-medium">{q.label}</div>
              </Card>
            </button>
          ))}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <Card dark={dark} className="p-6">
          <h3 className="font-semibold text-sm mb-4">Recommended for you</h3>
          <div className="space-y-3">
            {data.recommended_resources.length === 0 ? (
              <p className="text-sm text-slate-400">Check in a few times to unlock personalised picks.</p>
            ) : data.recommended_resources.map((r) => (
              <div key={r.id} className="flex items-center justify-between text-sm">
                <span className="text-slate-500">{r.title}</span>
                <Pill tone="accent">{r.type}</Pill>
              </div>
            ))}
          </div>
        </Card>
        <Card dark={dark} className="p-6">
          <h3 className="font-semibold text-sm mb-4">Your progress</h3>
          <div className="flex items-center gap-4">
            <Award size={28} style={{ color: COLORS.accent }} />
            <div>
              <div className="text-sm font-medium">{data.streak_days}-day check-in streak</div>
              <div className="text-xs text-slate-400">Keep logging daily to build your streak</div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ---------------------------- AI Chat ---------------------------- */

function AIChat({ dark }) {
  const [messages, setMessages] = useState([
    { role: "ai", content: "Hi, I'm here to listen. What's on your mind today? You can tell me things like \"I feel anxious\" or \"I can't sleep.\"" },
  ]);
  const [sessionId, setSessionId] = useState(null);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [crisis, setCrisis] = useState(false);
  const [error, setError] = useState("");
  const endRef = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  async function send() {
    if (!input.trim() || sending) return;
    const text = input;
    setInput("");
    setError("");
    setMessages((m) => [...m, { role: "user", content: text }]);
    setSending(true);
    try {
      const res = await sendChatMessage(text, sessionId);
      setSessionId(res.session_id);
      setMessages((m) => [...m, { role: "ai", content: res.reply }]);
      if (res.crisis) setCrisis(true);
    } catch (e) {
      setError(e.message);
      setMessages((m) => m.slice(0, -1));
      setInput(text);
    } finally {
      setSending(false);
    }
  }

  const suggestions = ["I feel anxious", "I can't sleep", "My exams are stressing me", "I want to quit college"];

  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})` }}>
          <Sparkles size={18} className="text-white" />
        </div>
        <div>
          <h2 className="font-semibold">AI First-Aid Support</h2>
          <p className="text-xs text-slate-400">Not a diagnosis. Not a replacement for therapy. Powered by Gemini.</p>
        </div>
      </div>

      <Card dark={dark} className="p-5 h-[440px] flex flex-col">
        <div className="flex-1 overflow-y-auto space-y-3 pr-1">
          {messages.map((m, i) => (
            <div key={i} className={`max-w-[85%] text-sm rounded-2xl px-4 py-2.5 leading-relaxed ${
              m.role === "user" ? `ml-auto rounded-tr-sm ${dark ? "bg-slate-700" : "bg-slate-100"}` : "rounded-tl-sm text-white"
            }`} style={m.role === "ai" ? { background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})` } : {}}>
              {m.content}
            </div>
          ))}
          {sending && (
            <div className="flex items-center gap-2 text-slate-400 text-xs pl-1">
              <Loader2 size={14} className="animate-spin" /> MindBridge is typing...
            </div>
          )}
          <div ref={endRef} />
        </div>

        {crisis && (
          <div className="mt-3 p-4 rounded-2xl border border-rose-200 bg-rose-50">
            <div className="flex items-center gap-2 text-rose-600 font-semibold text-sm mb-2">
              <AlertTriangle size={16} /> Immediate support available
            </div>
            <div className="space-y-1.5">
              {CRISIS_LINES.slice(0, 2).map((c, i) => (
                <div key={i} className="flex items-center justify-between text-xs">
                  <span className="text-rose-700">{c.name}</span>
                  <a href={`tel:${c.number.replace(/[^0-9+]/g, "")}`} className="font-semibold text-rose-600">{c.number}</a>
                </div>
              ))}
            </div>
            <PrimaryButton className="w-full mt-3 !py-2 text-xs" icon={Calendar}>Book urgent counsellor slot</PrimaryButton>
          </div>
        )}

        {error && <p className="text-xs text-rose-500 mt-2">{error}</p>}

        <div className="flex flex-wrap gap-2 mt-3">
          {suggestions.map((s, i) => (
            <button key={i} onClick={() => setInput(s)} className={`text-xs px-3 py-1.5 rounded-full border ${dark ? "border-slate-700 text-slate-300" : "border-slate-200 text-slate-500"}`}>{s}</button>
          ))}
        </div>
        <div className="flex items-center gap-2 mt-3">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send()}
            placeholder="Type how you're feeling..."
            disabled={sending}
            className={`flex-1 px-4 py-3 rounded-2xl border text-sm outline-none focus:ring-2 focus:ring-[#4F8EF7]/40 disabled:opacity-60 ${dark ? "bg-slate-900 border-slate-700" : "bg-slate-50 border-slate-200"}`}
          />
          <button onClick={send} disabled={sending} className="w-11 h-11 rounded-2xl flex items-center justify-center text-white shrink-0 disabled:opacity-60" style={{ background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})` }}>
            {sending ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
          </button>
        </div>
      </Card>
      <p className="text-[11px] text-slate-400 mt-3 text-center">
        Conversations are stored securely and linked only to your account for continuity of care.
      </p>
    </div>
  );
}

/* ---------------------------- Assessment (PHQ-9 / GAD-7) ---------------------------- */

const OPTIONS = ["Not at all", "Several days", "More than half the days", "Nearly every day"];

function Assessment({ dark }) {
  const [type, setType] = useState("PHQ9");
  const { data: qData, loading: qLoading, error: qError, refetch } = useApi(fetchAssessmentQuestions.bind(null, type), [type]);
  const [answers, setAnswers] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (qData) setAnswers(Array(qData.questions.length).fill(null));
    setResult(null);
  }, [qData]);

  if (qLoading) return <Spinner label="Loading questionnaire..." />;
  if (qError) return <ErrorState message={qError} onRetry={refetch} />;

  const complete = answers.length > 0 && answers.every((a) => a !== null);

  function level(score, t) {
    if (t === "PHQ9") {
      if (score <= 4) return { label: "Minimal", tone: "secondary" };
      if (score <= 9) return { label: "Mild", tone: "primary" };
      if (score <= 14) return { label: "Moderate", tone: "warn" };
      if (score <= 19) return { label: "Moderately severe", tone: "warn" };
      return { label: "Severe", tone: "danger" };
    }
    if (score <= 4) return { label: "Minimal", tone: "secondary" };
    if (score <= 9) return { label: "Mild", tone: "primary" };
    if (score <= 14) return { label: "Moderate", tone: "warn" };
    return { label: "Severe", tone: "danger" };
  }

  async function submit() {
    setError("");
    setSubmitting(true);
    try {
      const res = await submitAssessment({ type, answers });
      setResult(res);
    } catch (e) {
      setError(e.message);
    } finally {
      setSubmitting(false);
    }
  }

  if (result) {
    const lv = level(result.score, type);
    const maxScore = type === "PHQ9" ? 27 : 21;
    return (
      <div className="max-w-xl mx-auto">
        <Card dark={dark} className="p-8 text-center">
          <div className="w-14 h-14 rounded-2xl mx-auto flex items-center justify-center mb-4" style={{ background: `${COLORS.primary}15` }}>
            <ClipboardList size={24} style={{ color: COLORS.primary }} />
          </div>
          <h2 className="font-bold text-lg">Your {type} result</h2>
          <div className="text-4xl font-bold my-4" style={{ color: COLORS.primary }}>{result.score}<span className="text-base text-slate-400 font-normal"> /{maxScore}</span></div>
          <Pill tone={lv.tone}>{lv.label}</Pill>
          <p className="text-sm text-slate-400 mt-5 leading-relaxed">
            This is a screening tool, not a diagnosis. {lv.label === "Minimal" ? "Your responses suggest few symptoms right now — keep up your self-care habits." : "It may help to talk this through with a counsellor who can support you properly."}
          </p>
          {result.high_risk_flag && (
            <div className="mt-5 p-4 rounded-2xl border border-rose-200 bg-rose-50 text-left">
              <div className="flex items-center gap-2 text-rose-600 font-semibold text-sm mb-1"><AlertTriangle size={16} /> Please reach out for support</div>
              <p className="text-xs text-rose-600">Your responses indicate a need for extra support. Please contact a crisis line or campus counsellor now.</p>
            </div>
          )}
          <div className="flex gap-3 mt-6">
            <GhostButton dark={dark} className="flex-1" onClick={() => { setResult(null); refetch(); }}>Retake</GhostButton>
            <PrimaryButton className="flex-1" icon={Calendar}>Book a counsellor</PrimaryButton>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto">
      <div className="flex items-center gap-2 mb-4">
        {["PHQ9", "GAD7"].map((t) => (
          <button key={t} onClick={() => setType(t)} className={`px-3.5 py-1.5 rounded-full text-xs font-medium border ${type === t ? "text-white border-transparent" : dark ? "border-slate-700 text-slate-400" : "border-slate-200 text-slate-500"}`} style={type === t ? { background: COLORS.primary } : {}}>
            {t === "PHQ9" ? "PHQ-9 (Depression)" : "GAD-7 (Anxiety)"}
          </button>
        ))}
      </div>
      <h2 className="font-bold text-lg mb-1">{type} Screening</h2>
      <p className="text-sm text-slate-400 mb-6">Over the last 2 weeks, how often have you been bothered by any of the following?</p>
      <div className="space-y-4">
        {qData.questions.map((q, qi) => (
          <Card dark={dark} className="p-5" key={qi}>
            <p className="text-sm font-medium mb-3">{qi + 1}. {q}</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {OPTIONS.map((opt, oi) => (
                <button
                  key={oi}
                  onClick={() => setAnswers((a) => a.map((v, i) => (i === qi ? oi : v)))}
                  className={`text-xs px-2 py-2.5 rounded-xl border font-medium transition-colors ${
                    answers[qi] === oi ? "text-white border-transparent" : dark ? "border-slate-700 text-slate-400" : "border-slate-200 text-slate-500"
                  }`}
                  style={answers[qi] === oi ? { background: COLORS.primary } : {}}
                >
                  {opt}
                </button>
              ))}
            </div>
          </Card>
        ))}
      </div>
      {error && <p className="text-xs text-rose-500 mt-3">{error}</p>}
      <PrimaryButton className="w-full mt-6" onClick={submit} disabled={!complete} loading={submitting}>
        {complete ? "See my results" : `Answer all questions (${answers.filter((a) => a !== null).length}/${qData.questions.length})`}
      </PrimaryButton>
      <p className="text-[11px] text-slate-400 text-center mt-3">By continuing you consent to this assessment being stored securely and linked only to your anonymous ID.</p>
    </div>
  );
}

/* ---------------------------- Booking ---------------------------- */

function Booking({ dark }) {
  const { data: counsellors, loading, error, refetch } = useApi(fetchCounsellors, []);
  const [mode, setMode] = useState("online");
  const [anon, setAnon] = useState(true);
  const [booked, setBooked] = useState(null);
  const [bookingId, setBookingId] = useState(null);
  const [bookError, setBookError] = useState("");

  async function handleBook(counsellor) {
    setBookingId(counsellor.id);
    setBookError("");
    try {
      const scheduled = new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString();
      const appt = await bookAppointment({ counsellor_id: counsellor.id, mode, anonymous: anon, scheduled_time: scheduled });
      setBooked(appt);
    } catch (e) {
      setBookError(e.message);
    } finally {
      setBookingId(null);
    }
  }

  if (loading) return <Spinner label="Loading counsellors..." />;
  if (error) return <ErrorState message={error} onRetry={refetch} />;

  if (booked) {
    return (
      <div className="max-w-md mx-auto text-center">
        <Card dark={dark} className="p-8">
          <div className="w-16 h-16 rounded-2xl bg-[#6FCF97]/15 mx-auto flex items-center justify-center mb-4">
            <Check size={28} className="text-[#3fa76b]" />
          </div>
          <h2 className="font-bold text-lg">Appointment confirmed</h2>
          <p className="text-sm text-slate-400 mt-2">{booked.counsellor_name} · {new Date(booked.scheduled_time).toLocaleString()} · {mode === "online" ? "Online" : "In-person"}</p>
          <div className="mt-5 p-5 rounded-2xl bg-slate-50 flex flex-col items-center">
            <div className="w-28 h-28 rounded-xl bg-white border-2 border-dashed border-slate-300 flex items-center justify-center text-xs font-mono text-slate-400">{booked.qr_code}</div>
            <p className="text-xs text-slate-400 mt-3">Show this at the counselling centre, or it auto-verifies for online sessions.</p>
          </div>
          <GhostButton dark={dark} className="w-full mt-5" onClick={() => setBooked(null)}>Book another session</GhostButton>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <h2 className="font-bold text-lg mb-1">Book a counsellor</h2>
      <p className="text-sm text-slate-400 mb-6">Choose a mode and a counsellor. Your first consultation can be fully anonymous.</p>

      <div className="flex flex-wrap gap-3 mb-6">
        {[{ id: "online", label: "Online", icon: Video }, { id: "offline", label: "In person", icon: MapPin }].map((m) => (
          <button key={m.id} onClick={() => setMode(m.id)} className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium border ${mode === m.id ? "text-white border-transparent" : dark ? "border-slate-700 text-slate-400" : "border-slate-200 text-slate-500"}`} style={mode === m.id ? { background: COLORS.primary } : {}}>
            <m.icon size={15} /> {m.label}
          </button>
        ))}
        <label className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm border cursor-pointer ${dark ? "border-slate-700" : "border-slate-200"}`}>
          <input type="checkbox" checked={anon} onChange={(e) => setAnon(e.target.checked)} className="accent-[#4F8EF7]" />
          Keep this session anonymous
        </label>
      </div>

      {bookError && <p className="text-xs text-rose-500 mb-3">{bookError}</p>}

      <div className="space-y-3">
        {(counsellors || []).map((c) => (
          <Card dark={dark} key={c.id} className="p-5 flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl flex items-center justify-center font-semibold text-white shrink-0" style={{ background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})` }}>
                {c.full_name.split(" ").map((n) => n[0]).slice(-2).join("")}
              </div>
              <div>
                <div className="text-sm font-semibold">{c.full_name}</div>
                <div className="text-xs text-slate-400">{c.specialization}</div>
                <div className="flex items-center gap-1 text-xs text-amber-500 mt-0.5"><Star size={11} fill="currentColor" /> {c.rating}</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-xs text-slate-400 flex items-center gap-1"><Clock size={12} /> Next available: in 2 days</div>
              <PrimaryButton className="!px-4 !py-2 text-xs" onClick={() => handleBook(c)} loading={bookingId === c.id}>Book</PrimaryButton>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

/* ---------------------------- Resource Hub ---------------------------- */

function ResourceHub({ dark }) {
  const [cat, setCat] = useState("All");
  const [lang, setLang] = useState("English");
  const [query, setQuery] = useState("");
  const { data: cats } = useApi(fetchResourceCategories, []);
  const { data: langs } = useApi(fetchResourceLanguages, []);
  const { data: resources, loading, error, refetch } = useApi(
    () => fetchResources({ category: cat === "All" ? undefined : cat, language: lang, search: query }),
    [cat, lang, query]
  );

  const typeIcon = { Audio: Sparkles, Guide: BookOpen, PDF: ClipboardList, Video: Sparkles };

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
        <h2 className="font-bold text-lg">Resource Hub</h2>
        <select value={lang} onChange={(e) => setLang(e.target.value)} className={`px-3 py-2 rounded-xl border text-sm ${dark ? "bg-slate-900 border-slate-700" : "bg-white border-slate-200"}`}>
          {(langs?.languages || ["English"]).map((l) => <option key={l}>{l}</option>)}
        </select>
      </div>
      <div className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border mb-4 ${dark ? "bg-slate-900 border-slate-700" : "bg-white border-slate-200"}`}>
        <Search size={15} className="text-slate-400" />
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search resources..." className="flex-1 bg-transparent text-sm outline-none" />
      </div>
      <div className="flex gap-2 overflow-x-auto pb-2 mb-5">
        {(cats?.categories || ["All"]).map((c) => (
          <button key={c} onClick={() => setCat(c)} className={`shrink-0 px-3.5 py-1.5 rounded-full text-xs font-medium border ${cat === c ? "text-white border-transparent" : dark ? "border-slate-700 text-slate-400" : "border-slate-200 text-slate-500"}`} style={cat === c ? { background: COLORS.primary } : {}}>
            {c}
          </button>
        ))}
      </div>
      {loading ? <Spinner label="Loading resources..." /> : error ? <ErrorState message={error} onRetry={refetch} /> : (
        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
          {(resources || []).length === 0 && <p className="text-sm text-slate-400 col-span-full text-center py-10">No resources match your filters yet.</p>}
          {(resources || []).map((r) => {
            const Icon = typeIcon[r.type] || BookOpen;
            return (
              <Card dark={dark} key={r.id} className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: `${COLORS.accent}15` }}>
                    <Icon size={16} style={{ color: COLORS.accent }} />
                  </div>
                  <button className="text-slate-300 hover:text-[#4F8EF7]"><Bookmark size={16} /></button>
                </div>
                <h4 className="text-sm font-semibold leading-snug">{r.title}</h4>
                <div className="flex items-center gap-2 mt-3 text-xs text-slate-400">
                  <Pill tone="secondary">{r.category}</Pill>
                  <span>{r.type} · {r.duration_minutes} min</span>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ---------------------------- Mood Tracker ---------------------------- */

function MoodTracker({ dark }) {
  const [mood, setMood] = useState(null);
  const [sleep, setSleep] = useState(7);
  const [stress, setStress] = useState(5);
  const [journal, setJournal] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");
  const { data: history, loading, refetch } = useApi(() => fetchMoodHistory(7), []);

  const moods = [
    { id: "great", icon: Smile, label: "Great", color: "#6FCF97" },
    { id: "okay", icon: Meh, label: "Okay", color: "#4F8EF7" },
    { id: "low", icon: Frown, label: "Low", color: "#9B8AFB" },
  ];

  const chartData = (history || []).map((h) => ({
    day: new Date(h.created_at).toLocaleDateString(undefined, { weekday: "short" }),
    score: h.mood === "great" ? 9 : h.mood === "okay" ? 6 : 3,
  }));

  async function save() {
    if (!mood) return;
    setSaving(true);
    setError("");
    try {
      await submitMoodCheckin({ mood, sleep_hours: Number(sleep), stress_level: Number(stress), journal: journal || null });
      setSaved(true);
      refetch();
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div>
        <h2 className="font-bold text-lg mb-1">Daily check-in</h2>
        <p className="text-sm text-slate-400 mb-5">Takes about 20 seconds.</p>
        <Card dark={dark} className="p-6">
          <p className="text-sm font-medium mb-3">How are you feeling today?</p>
          <div className="grid grid-cols-3 gap-3 mb-5">
            {moods.map((m) => (
              <button key={m.id} onClick={() => { setMood(m.id); setSaved(false); }} className={`flex flex-col items-center gap-2 p-4 rounded-2xl border-2 transition-colors ${mood === m.id ? "" : dark ? "border-slate-700" : "border-slate-100"}`} style={mood === m.id ? { borderColor: m.color, background: `${m.color}12` } : {}}>
                <m.icon size={26} style={{ color: m.color }} />
                <span className="text-xs font-medium">{m.label}</span>
              </button>
            ))}
          </div>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-xs text-slate-400 mb-1"><span className="flex items-center gap-1"><MoonIcon size={12} /> Sleep hours</span><span>{sleep}h</span></div>
              <input type="range" min="0" max="12" value={sleep} onChange={(e) => setSleep(e.target.value)} className="w-full accent-[#4F8EF7]" />
            </div>
            <div>
              <div className="flex justify-between text-xs text-slate-400 mb-1"><span className="flex items-center gap-1"><Droplet size={12} /> Stress level</span><span>{stress}/10</span></div>
              <input type="range" min="0" max="10" value={stress} onChange={(e) => setStress(e.target.value)} className="w-full accent-[#9B8AFB]" />
            </div>
            <textarea value={journal} onChange={(e) => setJournal(e.target.value)} placeholder="Anything on your mind? (optional journal entry)" rows={3} className={`w-full px-3 py-2.5 rounded-xl border text-sm outline-none ${dark ? "bg-slate-900 border-slate-700" : "bg-slate-50 border-slate-200"}`} />
          </div>
          {error && <p className="text-xs text-rose-500 mt-3">{error}</p>}
          <PrimaryButton className="w-full mt-5" onClick={save} disabled={!mood} loading={saving}>{saved ? "Saved ✓" : "Save check-in"}</PrimaryButton>
        </Card>
      </div>
      <div>
        <h3 className="font-semibold text-sm mb-3">Your week</h3>
        <Card dark={dark} className="p-6">
          {loading ? <Spinner label="Loading history..." /> : chartData.length === 0 ? (
            <p className="text-sm text-slate-400 py-10 text-center">Log a few check-ins to see your weekly trend.</p>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={dark ? "#1e293b" : "#eef2f7"} />
                <XAxis dataKey="day" tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                <YAxis hide domain={[0, 10]} />
                <Tooltip contentStyle={{ borderRadius: 12, border: "none", fontSize: 12 }} />
                <Line type="monotone" dataKey="score" stroke={COLORS.accent} strokeWidth={2.5} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          )}
          <div className="mt-4 p-3 rounded-xl bg-slate-50 text-xs text-slate-500 flex items-start gap-2">
            <TrendingUp size={14} className="mt-0.5 shrink-0" style={{ color: COLORS.secondary }} />
            Patterns become clearer after a week of consistent check-ins — keep going!
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ---------------------------- Peer Support ---------------------------- */

function PeerSupport({ dark }) {
  const { data: posts, loading, error, refetch } = useApi(fetchPeerPosts, []);
  const [content, setContent] = useState("");
  const [posting, setPosting] = useState(false);
  const [err, setErr] = useState("");

  async function submitPost() {
    if (!content.trim()) return;
    setPosting(true);
    setErr("");
    try {
      await createPeerPost({ content, tag: "Support" });
      setContent("");
      refetch();
    } catch (e) {
      setErr(e.message);
    } finally {
      setPosting(false);
    }
  }

  return (
    <div className="max-w-2xl mx-auto">
      <h2 className="font-bold text-lg mb-1">Peer Support Community</h2>
      <p className="text-sm text-slate-400 mb-5">Anonymous, moderated by trained student volunteers.</p>
      <Card dark={dark} className="p-4 mb-2 flex items-center gap-3">
        <div className="w-9 h-9 rounded-full bg-slate-200 shrink-0" />
        <input
          value={content}
          onChange={(e) => setContent(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && submitPost()}
          placeholder="Share something with the community, anonymously..."
          className={`flex-1 px-4 py-2.5 rounded-full border text-sm outline-none ${dark ? "bg-slate-900 border-slate-700" : "bg-slate-50 border-slate-200"}`}
        />
        <PrimaryButton className="!px-4 !py-2 text-xs" onClick={submitPost} loading={posting}>Post</PrimaryButton>
      </Card>
      {err && <p className="text-xs text-rose-500 mb-3">{err}</p>}

      {loading ? <Spinner label="Loading posts..." /> : error ? <ErrorState message={error} onRetry={refetch} /> : (
        <div className="space-y-3">
          {(posts || []).map((p) => (
            <Card dark={dark} key={p.id} className="p-5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500">{p.author_display}</span>
                <Pill tone="accent">{p.tag}</Pill>
              </div>
              <p className="text-sm">{p.content}</p>
              <div className="flex items-center gap-4 mt-3 text-xs text-slate-400">
                <span>💬 {p.reply_count} replies</span>
                <button className="hover:text-rose-400" onClick={() => reportPost(p.id).then(refetch)}>Report</button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---------------------------- Admin Dashboard ---------------------------- */

const PIE_COLORS = [COLORS.primary, COLORS.accent];

function AdminDashboard({ dark }) {
  const { data, loading, error, refetch } = useApi(fetchAdminAnalytics, []);

  if (loading) return <Spinner label="Crunching campus-wide analytics..." />;
  if (error) return <ErrorState message={error} onRetry={refetch} />;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="font-bold text-lg">Campus wellness analytics</h2>
          <p className="text-sm text-slate-400">Fully anonymized · never linked to individual identity</p>
        </div>
        <div className="flex gap-2">
          <GhostButton dark={dark} className="!py-2 text-xs" onClick={refetch}>Refresh</GhostButton>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { l: "Avg. stress score", v: data.avg_stress_score, tone: "warn" },
          { l: "Students screened", v: `${data.students_screened} / ${data.total_students}`, tone: "secondary" },
          { l: "High-risk flags", v: data.high_risk_flags, tone: "danger" },
          { l: "Active AI chats (7d)", v: data.active_chats_7d, tone: "primary" },
        ].map((k, i) => (
          <Card dark={dark} key={i} className="p-5">
            <div className="text-xs text-slate-400">{k.l}</div>
            <div className="text-2xl font-bold mt-1">{k.v}</div>
            <Pill tone={k.tone}>live</Pill>
          </Card>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        <Card dark={dark} className="p-6 lg:col-span-2">
          <h3 className="font-semibold text-sm mb-4">Anxiety &amp; depression trend</h3>
          {data.monthly_trend.length === 0 ? (
            <p className="text-sm text-slate-400 py-10 text-center">Not enough assessment data yet to chart a trend.</p>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={data.monthly_trend}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={dark ? "#1e293b" : "#eef2f7"} />
                <XAxis dataKey="m" tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ borderRadius: 12, border: "none", fontSize: 12 }} />
                <Line type="monotone" dataKey="anxiety" stroke={COLORS.primary} strokeWidth={2.5} dot={false} name="Anxiety" />
                <Line type="monotone" dataKey="depression" stroke={COLORS.accent} strokeWidth={2.5} dot={false} name="Depression" />
              </LineChart>
            </ResponsiveContainer>
          )}
          <div className="flex gap-4 mt-2 text-xs text-slate-400">
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full" style={{ background: COLORS.primary }} /> Anxiety (GAD-7)</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full" style={{ background: COLORS.accent }} /> Depression (PHQ-9)</span>
          </div>
        </Card>
        <Card dark={dark} className="p-6">
          <h3 className="font-semibold text-sm mb-4">Hostel vs. day scholar</h3>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={data.hostel_split} dataKey="value" nameKey="name" innerRadius={45} outerRadius={70} paddingAngle={3}>
                {data.hostel_split.map((_, i) => <Cell key={i} fill={PIE_COLORS[i]} />)}
              </Pie>
              <Tooltip contentStyle={{ borderRadius: 12, border: "none", fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex justify-center gap-4 text-xs text-slate-400 mt-1">
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full" style={{ background: COLORS.primary }} /> Hostel</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full" style={{ background: COLORS.accent }} /> Day scholar</span>
          </div>
        </Card>
      </div>

      <Card dark={dark} className="p-6">
        <h3 className="font-semibold text-sm mb-4">Department-wise stress score</h3>
        {data.department_stress.length === 0 ? (
          <p className="text-sm text-slate-400 py-10 text-center">No department-linked mood data yet.</p>
        ) : (
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={data.department_stress}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={dark ? "#1e293b" : "#eef2f7"} />
              <XAxis dataKey="dept" tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ borderRadius: 12, border: "none", fontSize: 12 }} />
              <Bar dataKey="score" fill={COLORS.secondary} radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </Card>
    </div>
  );
}

/* ---------------------------- Counsellor / Volunteer views ---------------------------- */

function CounsellorDashboard({ dark }) {
  const { data, loading, error, refetch } = useApi(fetchCounsellorDashboard, []);
  if (loading) return <Spinner label="Loading appointments..." />;
  if (error) return <ErrorState message={error} onRetry={refetch} />;

  return (
    <div className="space-y-6">
      <h2 className="font-bold text-lg">Today's appointments</h2>
      <div className="grid md:grid-cols-2 gap-5">
        <Card dark={dark} className="p-5">
          {data.today_appointments.length === 0 ? (
            <p className="text-sm text-slate-400 py-6 text-center">No appointments scheduled for today.</p>
          ) : data.today_appointments.map((a) => (
            <div key={a.id} className="flex items-center justify-between py-3 border-b last:border-0 border-slate-100">
              <div>
                <div className="text-sm font-medium">{a.display_name}</div>
                <div className="text-xs text-slate-400">{a.time}</div>
              </div>
              <Pill tone={a.status === "Confirmed" ? "secondary" : "warn"}>{a.status}</Pill>
            </div>
          ))}
        </Card>
        <Card dark={dark} className="p-5">
          <h3 className="font-semibold text-sm mb-3">Risk alerts</h3>
          {data.risk_alerts.length === 0 ? (
            <p className="text-sm text-slate-400">No active risk alerts.</p>
          ) : data.risk_alerts.map((a, i) => (
            <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-rose-50 mb-2 last:mb-0">
              <AlertTriangle size={16} className="text-rose-500 shrink-0" />
              <div className="text-xs text-rose-600">{a.student_display} scored "{a.risk_level}" on {a.type} — follow-up recommended.</div>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

function VolunteerDashboard({ dark }) {
  const { data, loading, error, refetch } = useApi(fetchVolunteerDashboard, []);
  if (loading) return <Spinner label="Loading volunteer hub..." />;
  if (error) return <ErrorState message={error} onRetry={refetch} />;

  return (
    <div className="space-y-6">
      <h2 className="font-bold text-lg">Volunteer hub</h2>
      <div className="grid md:grid-cols-3 gap-5">
        <Card dark={dark} className="p-5"><div className="text-xs text-slate-400">Assigned check-ins</div><div className="text-2xl font-bold mt-1">{data.assigned_checkins}</div></Card>
        <Card dark={dark} className="p-5"><div className="text-xs text-slate-400">Posts to moderate</div><div className="text-2xl font-bold mt-1">{data.posts_to_moderate}</div></Card>
        <Card dark={dark} className="p-5"><div className="text-xs text-slate-400">Training modules left</div><div className="text-2xl font-bold mt-1">{data.training_modules_left}</div></Card>
      </div>
    </div>
  );
}

/* ---------------------------- Root App ---------------------------- */

export default function MindBridgeApp() {
  const [stage, setStage] = useState("landing"); // landing | auth | app | bootstrapping
  const [authMode, setAuthMode] = useState("login");
  const [user, setUser] = useState(null);
  const [active, setActive] = useState("dashboard");
  const [dark, setDark] = useState(false);
  const [showEmergency, setShowEmergency] = useState(false);
  const [bootLoading, setBootLoading] = useState(true);

  const logout = useCallback(() => {
    localStorage.removeItem("mindbridge_token");
    localStorage.removeItem("mindbridge_user");
    setUser(null);
    setStage("landing");
  }, []);

  useEffect(() => {
    registerUnauthorizedHandler(logout);
  }, [logout]);

  useEffect(() => {
    const token = localStorage.getItem("mindbridge_token");
    if (!token) { setBootLoading(false); return; }
    fetchMe()
      .then((u) => {
        setUser(u);
        setActive(u.role === "student" ? "dashboard" : u.role);
        setStage("app");
      })
      .catch(() => logout())
      .finally(() => setBootLoading(false));
  }, [logout]);

  function handleAuthed(token, userObj) {
    localStorage.setItem("mindbridge_token", token);
    localStorage.setItem("mindbridge_user", JSON.stringify(userObj));
    setUser(userObj);
    setActive(userObj.role === "student" ? "dashboard" : userObj.role);
    setStage("app");
  }

  if (bootLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F8FAFC]">
        <Spinner label="Starting MindBridge..." />
      </div>
    );
  }

  if (stage === "landing") {
    return (
      <div className="font-sans">
        <Landing goAuth={(m) => { setAuthMode(m); setStage("auth"); }} dark={dark} setDark={setDark} />
        <EmergencyFAB onOpen={() => setShowEmergency(true)} />
        {showEmergency && <EmergencyModal onClose={() => setShowEmergency(false)} />}
      </div>
    );
  }

  if (stage === "auth") {
    return (
      <div className="font-sans">
        <AuthScreen mode={authMode} setMode={setAuthMode} onAuthed={handleAuthed} dark={dark} />
        <EmergencyFAB onOpen={() => setShowEmergency(true)} />
        {showEmergency && <EmergencyModal onClose={() => setShowEmergency(false)} />}
      </div>
    );
  }

  const role = user?.role || "student";
  const views = {
    dashboard: <StudentDashboard dark={dark} setActive={setActive} />,
    chat: <AIChat dark={dark} />,
    assessment: <Assessment dark={dark} />,
    booking: <Booking dark={dark} />,
    resources: <ResourceHub dark={dark} />,
    mood: <MoodTracker dark={dark} />,
    peer: <PeerSupport dark={dark} />,
    admin: <AdminDashboard dark={dark} />,
    counsellor: <CounsellorDashboard dark={dark} />,
    volunteer: <VolunteerDashboard dark={dark} />,
  };

  return (
    <div className="font-sans">
      <Shell role={role} active={active} setActive={setActive} dark={dark} setDark={setDark} onLogout={logout}>
        {views[active] || views.dashboard}
      </Shell>
      <EmergencyFAB onOpen={() => setShowEmergency(true)} />
      {showEmergency && <EmergencyModal onClose={() => setShowEmergency(false)} />}
    </div>
  );
}

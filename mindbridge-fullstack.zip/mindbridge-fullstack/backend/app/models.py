import enum
import uuid
from datetime import datetime

from sqlalchemy import (
    Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Text, Enum as SAEnum, JSON
)
from sqlalchemy.orm import relationship

from .database import Base


def gen_anon_id() -> str:
    return f"Anon{uuid.uuid4().int % 10000:04d}"


class RoleEnum(str, enum.Enum):
    student = "student"
    counsellor = "counsellor"
    volunteer = "volunteer"
    admin = "admin"


class MoodEnum(str, enum.Enum):
    great = "great"
    okay = "okay"
    low = "low"


class AssessmentTypeEnum(str, enum.Enum):
    PHQ9 = "PHQ9"
    GAD7 = "GAD7"


class RiskLevelEnum(str, enum.Enum):
    minimal = "Minimal"
    mild = "Mild"
    moderate = "Moderate"
    moderately_severe = "Moderately severe"
    severe = "Severe"


class AppointmentModeEnum(str, enum.Enum):
    online = "online"
    offline = "offline"


class AppointmentStatusEnum(str, enum.Enum):
    pending = "Pending"
    confirmed = "Confirmed"
    completed = "Completed"
    cancelled = "Cancelled"


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String, nullable=False)
    role = Column(SAEnum(RoleEnum), default=RoleEnum.student, nullable=False)
    anonymous_id = Column(String, unique=True, default=gen_anon_id)

    department = Column(String, nullable=True)
    year = Column(String, nullable=True)
    is_hostel = Column(Boolean, default=False)

    # counsellor-only profile fields
    specialization = Column(String, nullable=True)
    rating = Column(Float, default=4.8)

    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    mood_logs = relationship("MoodLog", back_populates="user", cascade="all, delete-orphan")
    assessments = relationship("Assessment", back_populates="user", cascade="all, delete-orphan")
    chat_messages = relationship("ChatMessage", back_populates="user", cascade="all, delete-orphan")
    notifications = relationship("Notification", back_populates="user", cascade="all, delete-orphan")
    appointments_as_student = relationship(
        "Appointment", back_populates="student", foreign_keys="Appointment.student_id"
    )
    appointments_as_counsellor = relationship(
        "Appointment", back_populates="counsellor", foreign_keys="Appointment.counsellor_id"
    )


class MoodLog(Base):
    __tablename__ = "mood_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    mood = Column(SAEnum(MoodEnum), nullable=False)
    sleep_hours = Column(Float, default=7)
    stress_level = Column(Integer, default=5)
    journal = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="mood_logs")


class Assessment(Base):
    __tablename__ = "assessments"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    type = Column(SAEnum(AssessmentTypeEnum), nullable=False)
    answers = Column(JSON, nullable=False)
    score = Column(Integer, nullable=False)
    risk_level = Column(SAEnum(RiskLevelEnum), nullable=False)
    high_risk_flag = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="assessments")


class ChatMessage(Base):
    __tablename__ = "chat_messages"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    session_id = Column(String, index=True, nullable=False)
    role = Column(String, nullable=False)  # "user" | "ai"
    content = Column(Text, nullable=False)
    crisis_flag = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="chat_messages")


class Resource(Base):
    __tablename__ = "resources"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    category = Column(String, nullable=False)
    type = Column(String, nullable=False)  # Audio | Guide | PDF | Video
    duration_minutes = Column(Integer, default=5)
    language = Column(String, default="English")
    created_at = Column(DateTime, default=datetime.utcnow)


class Appointment(Base):
    __tablename__ = "appointments"

    id = Column(Integer, primary_key=True, index=True)
    student_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    counsellor_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    mode = Column(SAEnum(AppointmentModeEnum), default=AppointmentModeEnum.online)
    anonymous = Column(Boolean, default=True)
    scheduled_time = Column(DateTime, nullable=False)
    status = Column(SAEnum(AppointmentStatusEnum), default=AppointmentStatusEnum.confirmed)
    qr_code = Column(String, default=lambda: uuid.uuid4().hex[:12].upper())
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    student = relationship("User", back_populates="appointments_as_student", foreign_keys=[student_id])
    counsellor = relationship("User", back_populates="appointments_as_counsellor", foreign_keys=[counsellor_id])


class ForumPost(Base):
    __tablename__ = "forum_posts"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    author_display = Column(String, nullable=False)
    content = Column(Text, nullable=False)
    tag = Column(String, default="Support")
    reply_count = Column(Integer, default=0)
    report_count = Column(Integer, default=0)
    is_hidden = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    type = Column(String, default="info")  # info | reminder | alert
    message = Column(String, nullable=False)
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="notifications")

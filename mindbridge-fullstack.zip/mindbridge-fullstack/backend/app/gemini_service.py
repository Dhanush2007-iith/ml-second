import logging
from typing import List, Tuple, Dict

from .config import settings

logger = logging.getLogger("mindbridge.ai")

CRISIS_KEYWORDS = [
    "suicide", "kill myself", "end my life", "self harm", "self-harm",
    "hurt myself", "don't want to live", "want to die", "no reason to live",
    "better off dead",
]

CRISIS_LINES: List[Dict[str, str]] = [
    {"name": "KIRAN Mental Health Helpline (Govt. of India)", "number": "1800-599-0019", "availability": "24/7, toll-free"},
    {"name": "Vandrevala Foundation Helpline", "number": "1860-2662-345", "availability": "24/7"},
    {"name": "iCall (TISS)", "number": "9152987821", "availability": "Mon-Sat, 10am-8pm"},
    {"name": "Campus Counsellor (on-call)", "number": "Ext. 4477", "availability": "24/7 for enrolled students"},
]

SYSTEM_PROMPT = (
    "You are MindBridge, a warm, calm mental-health first-aid assistant for college students. "
    "You never diagnose, never replace therapy, and always keep responses short (2-4 sentences), "
    "supportive, and practical. Offer grounding techniques, breathing exercises, CBT-inspired "
    "reframing, sleep hygiene or study tips as relevant. Gently encourage professional support "
    "for anything serious. Do not provide medical or clinical advice beyond first-aid coping "
    "strategies."
)


def contains_crisis_language(text: str) -> bool:
    lower = text.lower()
    return any(k in lower for k in CRISIS_KEYWORDS)


def _rule_based_reply(text: str) -> str:
    lower = text.lower()
    if "sleep" in lower:
        return ("Trouble sleeping often comes from a racing mind. Try this tonight: no screens 30 "
                "minutes before bed, and write down tomorrow's worries on paper so your brain can "
                "let them go. Want a short wind-down routine?")
    if "anx" in lower:
        return ("Anxiety can feel like a wave. Let's ground you: name 5 things you can see, 4 you "
                "can touch, 3 you can hear, 2 you can smell, 1 you can taste. Want to try a "
                "breathing exercise too?")
    if "exam" in lower or "stress" in lower:
        return ("Exam stress is so common, and it doesn't mean you're not capable. Could we break "
                "your revision into one small, doable task for the next 25 minutes, then take a "
                "real break?")
    if "nobody likes me" in lower or "lonely" in lower or "alone" in lower:
        return ("That sounds really painful to sit with. Those thoughts can feel very convincing "
                "when we're low - they're not always accurate. Would it help to talk about one "
                "person you do feel safe around, even a little?")
    if "quit" in lower:
        return ("Wanting to quit often means you're carrying more than you can hold right now, not "
                "that you've failed. Would it help to talk this through with a counsellor who can "
                "look at your options with you?")
    return ("Thank you for sharing that with me. Can you tell me a little more about how this has "
            "been affecting your day-to-day?")


def _gemini_reply(message: str, history: List[Dict[str, str]]) -> str:
    import google.generativeai as genai

    genai.configure(api_key=settings.GEMINI_API_KEY)
    model = genai.GenerativeModel(settings.GEMINI_MODEL, system_instruction=SYSTEM_PROMPT)

    chat_history = []
    for h in history[-10:]:
        chat_history.append({
            "role": "user" if h["role"] == "user" else "model",
            "parts": [h["content"]],
        })

    chat = model.start_chat(history=chat_history)
    response = chat.send_message(message)
    return response.text.strip()


def get_ai_response(message: str, history: List[Dict[str, str]]) -> Tuple[str, bool]:
    """Returns (reply_text, crisis_flag). Crisis detection always runs locally,
    regardless of whether Gemini is configured, since this is safety-critical."""
    crisis = contains_crisis_language(message)

    if crisis:
        reply = (
            "I'm really glad you told me this, and I want to make sure you get real support right "
            "now - not just a chat. I'm showing you emergency options below. You matter, and "
            "immediate help is available."
        )
        return reply, True

    if settings.GEMINI_API_KEY:
        try:
            return _gemini_reply(message, history), False
        except Exception as exc:  # noqa: BLE001
            logger.warning("Gemini API call failed, falling back to rule-based reply: %s", exc)

    return _rule_based_reply(message), False
